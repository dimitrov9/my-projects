from sphero.request.spherorequest import SpheroRequest


class Roll(SpheroRequest):

    CID = 0x30
    FMT = '!BHB'
