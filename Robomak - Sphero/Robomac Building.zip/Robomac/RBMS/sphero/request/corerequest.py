from sphero.request.request import Request


class CoreRequest(Request):

    DID = 0x00
