from sphero.request.corerequest import CoreRequest


class Sleep(CoreRequest):

    CID = 0x22
    FMT = '!HBH'
