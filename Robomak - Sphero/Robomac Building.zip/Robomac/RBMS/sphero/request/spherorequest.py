from sphero.request.request import Request


class SpheroRequest(Request):

    DID = 0x02
