class ConnectionFailed(Exception):

    pass
