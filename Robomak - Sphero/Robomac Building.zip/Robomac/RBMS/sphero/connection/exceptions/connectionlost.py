class ConnectionLost(Exception):

    pass
