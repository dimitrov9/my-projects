
#%% Imports
import sphero  #it allows you to conect with your sphero, you have this library in your RBMS folder
import time
#%%
sph = sphero.Sphero('68:86:E7:07:1F:F8') # connection with the sphero (you should look for the adress in your bluetooth setings)

#%%
sph.set_rgb(0,255,0) # with this function you can change the colours(RGB) of your sphero

#%%
#sph.roll(60,0) #with this function (using polar cordinates) you make your sphero move (first integer indicates speed, and the second integer indicates the angle)

sph.roll(30,0)
time.sleep(1.6)
sph.roll(0,0)
#time.sleep(4)
#sph.roll(0,0)


"""while 1:
    a = input('speed \n')
    a = int(a)
    b = input('angle\n')
    b = int(b)
    print(a)
    sph.roll(a, b)
    sph.roll(a, b)
    break"""


"""a=input()
   if a=='q':
       break;
   elif a=='w':
       sph.roll(50,0)
       sph.roll(20,180)
   elif a=='s':
       sph.roll(50,180)
   elif a=='a':
       sph.roll(50,270)
   elif a=='d':
       sph.roll(50,90)"""
